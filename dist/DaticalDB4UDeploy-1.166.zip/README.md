DaticalDB4UDeploy
=================

This plugin brings Datical DB functionality to IBM UrbanCode uDeploy.

Two properties in the plugin step, Datical DB Install Directory and Datical DB Drivers Directory, read a default property at the resource (Agent) level. For each agent that is going to execute Datical DB, create a Resource Property called daticalDBCmd and daticalDBDriversDir.  
